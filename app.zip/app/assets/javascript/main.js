// ES6 or Vanilla JavaScript
